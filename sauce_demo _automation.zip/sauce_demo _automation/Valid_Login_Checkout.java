package automationtesting.task.SauceDemo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Valid_Login_Checkout {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//Login with given credential
		WebElement username = driver.findElement(By.id("user-name"));
		username.sendKeys("standard_user");
		WebElement password = driver.findElement(By.id("password"));
		password.sendKeys("secret_sauce");
		WebElement login = driver.findElement(By.id("login-button"));
		login.click();
		
		//Add two product to the cart
		WebElement product1 = driver.findElement(By.id("add-to-cart-sauce-labs-backpack"));
		product1.click();
		String Product1text = driver.findElement(By.xpath("(//div[@class='inventory_item_name '])[1]")).getText();
		WebElement product2 = driver.findElement(By.id("add-to-cart-sauce-labs-bolt-t-shirt"));
		product2.click();
		String product2text = driver.findElement(By.xpath("(//div[@class='inventory_item_name '])[3]")).getText();
		
		//Open cart verify selected products are present
		WebElement addtokart 
		 = driver.findElement(By.xpath("//a[@class='shopping_cart_link']"));
		addtokart.click();
		WebElement cart1 = driver.findElement(By.xpath("(//div[@class='inventory_item_name'])[1]"));
		String cart1text = cart1.getText();
		WebElement cart2 = driver.findElement(By.xpath("(//div[@class='inventory_item_name'])[2]"));
		String cart2text = cart2.getText();
		if(Product1text.contains(cart1text) && product2text.contains(cart2text))
		{
			System.out.println("Selected product present in the cart");
			
		}
		else
		{
			System.out.println("Different product present in the cart");
		}
		
		//Proceed to checkout
		WebElement checkout = driver.findElement(By.xpath("//button[@class='btn btn_action btn_medium checkout_button ']"));
		checkout.click();
		
		//Enter details
		WebElement firstname = driver.findElement(By.xpath("(//input[@class='input_error form_input'])[1]"));
		firstname.sendKeys("Jayapriya");
		WebElement lastname = driver.findElement(By.xpath("(//input[@class='input_error form_input'])[2]"));
		lastname.sendKeys("R");
		WebElement postalcode = driver.findElement(By.xpath("(//input[@class='input_error form_input'])[3]"));
		postalcode.sendKeys("600041");
		WebElement continuebutton = driver.findElement(By.xpath("(//input[@class='submit-button btn btn_primary cart_button btn_action'])[1]"));
		continuebutton.click();
		
		//Complete the order
		WebElement finish = driver.findElement(By.id("finish"));
		finish.click();
		
		//Verify success message
		String successmessage = 
		driver.findElement(By.xpath("//h2[@class='complete-header']")).getText();
		if(successmessage.contains("Thank you for your order"))
				{
			System.out.println("Order completed successfully");
				}
		else
		{
			System.out.println("Order not completed");
		}
		
		
		
		
	}

}
